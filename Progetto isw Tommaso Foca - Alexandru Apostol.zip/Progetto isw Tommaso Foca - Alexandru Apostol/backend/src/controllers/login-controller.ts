import { Request, Response } from "express"
import { connection } from "../utils/db"

/*export async function inviaDatiController(req: Request, res: Response): Promise<void> {
  try {
    const { nome, cognome, username, email, password, eta, genere, professione, ruolo } = req.body;

    // Esecuzione query per inserire i dati nel database
    const query = 'INSERT INTO utenti (nome, cognome, username, email, password, eta, genere, professione, ruolo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    const values = [nome, cognome, username, email, password, eta, genere, professione, ruolo]

    
    connection.query(query, values, (error, results) => {
      if (error) {
        console.error('Errore durante l\'inserimento dell\'utente nel database:', error);
        res.status(500).json({ error: 'Errore durante la registrazione dell\'utente' });
      } else {
        console.log('Utente registrato con successo');
        res.status(200).json({ message: 'Utente registrato con successo' });
      }
    });
  } catch (error) {
    console.error('Errore durante la registrazione dell\'utente:', error);
    res.status(500).json({ error: 'Errore durante la registrazione dell\'utente' });
  }
};*/


export async function inviaDatiController(req: Request, res: Response): Promise<void> {
  try {
    const { nome, cognome, username, email, password, eta, genere, professione, ruolo } = req.body;

    // Esecuzione query per inserire i dati nel database
    const query = `
      INSERT INTO utenti (nome, cognome, username, email, password, eta, genere, professione, ruolo)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const values = [nome, cognome, username, email, password, eta, genere, professione, ruolo];

    connection.execute(query, values, (error, results) => {
      if (error) {
        console.error('Errore durante l\'inserimento dell\'utente nel database:', error);
        res.status(500).json({ error: 'Errore durante la registrazione dell\'utente' });
      } else {
        console.log('Utente registrato con successo');
        res.status(200).json({ message: 'Utente registrato con successo' });
      }
    });
  } catch (error) {
    console.error('Errore durante la registrazione dell\'utente:', error);
    res.status(500).json({ error: 'Errore durante la registrazione dell\'utente' });
  }
}