import { Router } from "express"
import * as loginController from "../controllers/login-controller"

const router: Router = Router()

router.post('/api/register', loginController.inviaDatiController);

export default router
