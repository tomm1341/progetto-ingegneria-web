<template>
    <div>
        <div class="container-fluid">
        <div class="row text-center mt-3">
          <h1 class="">Forum</h1>
        </div>
            <div class="row d-grid gap-auto row-gap-4">
                <article class="container col-6 bg-secondary p-4 border border-black rounded shadow" v-for="Question in Domande">
                    <h2>Domanda numero: {{ Question.id_domanda }}</h2>
                    <h3>By : {{ Question.id_utente }}</h3>
                    <p>{{ Question.testo_domanda }}</p>
                </article>
                <aside class="col-6 float-end">
                  <h3>Popular</h3>
                </aside>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import axios from "axios"
import { defineComponent } from "vue"
import { Domanda } from "../types"

export default defineComponent({
  data() {
    return {
      Domande: [] as Domanda []
    }
  },
  methods: {
    Questions: function(){
       axios.get("/api/forum")
        .then(response => this.Domande = response.data);
    }
  },
  mounted(){
    this.Questions()
  }
})
</script>

